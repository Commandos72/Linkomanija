import xbmc

xbmc.executebuiltin('Addon.OpenSettings(script.media.aggregator)')
