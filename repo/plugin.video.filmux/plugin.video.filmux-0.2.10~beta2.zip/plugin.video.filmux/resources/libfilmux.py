# -*- coding: utf-8 -*-
import urllib2
import urllib
from bs4 import BeautifulSoup
from static import *
import re
import json


def _make_beautifulsoup(url, data=None, headers=None):
    log("MAKE SOUP:" + url)
    if data:
        urldata = urllib.urlencode(data)
        log("MAKE SOUP: POST DATA: " + urldata)
        req = urllib2.Request(url, urldata)
    else:
        req = urllib2.Request(url)
    if headers is not None:
        for header, value in headers.items():
            req.add_header(header, value)
    req.add_header('User-Agent', user_agent)
    response = urllib2.urlopen(req, timeout=15)
    data = response.read()
    soup = BeautifulSoup(data.decode('utf-8', 'ignore'), "html.parser")
    response.close()
    return soup


def _fix_url(link):
    if root_url_sort not in link:
        link = root_url + link
    if link[:2] == "//":
        link = "http:" + link
    if 'thumbs/' in link:
        link = link.replace('thumbs/', '')
    link = link.replace("http://", "https://")
    return link


def _process_titles(title, otitle=None, year=None):
    """
    Formats title strings and extracts season number
    :param title: Translated title
    :param otitle: Original title
    :return:
    """
    #year = re.search(r"(\(((\d{4})|(\d{4})-\d{4})\))", title)
    if year:
        title = title.replace(year.group(1), '')
        year = year.group(3) or year.group(4)
    season = None
    sre = re.compile(r"(\(((\d+) Sezonas|Season (\d+))\))", re.I)
    for match in sre.finditer(title):
        title = title.replace(match.group(1), '')
        season = int(match.group(3) or match.group(4))

    if otitle:
        for match in sre.finditer(otitle):
            otitle = otitle.replace(match.group(1), '')
            season = int(match.group(3) or match.group(4))
        otitle = otitle.strip()

    title = title.strip()
    if title.count('/') == 1:
        title = title[:title.index('/')].strip()

    if season and year:
        title = "{} (sezonas {}, {})".format(title, season, year)
    elif season:
        title = "{} ({} sezonas)".format(title, season)
    elif year:
        title = "{} ({})".format(title, year)
    return title, otitle, season

# def _process_s_fields(data):
#     for p in data.find_all('p'):
#         em = p.find('em')
#         if not em:
#             continue
#         ftt = em.getText()
#
# def _process_ftt(data):


def _process_fields(table, data):
    info = data.info
    for p in table.find_all('p'):
        ftt = p.find('em')
        if not ftt:
            continue
        ftt = ftt.getText()
        if ftt == u'Metai:' and not info.year:
            val = p.find('span')
            info.year = None if not val else val.getText().replace(' ', '')[:4]

        elif ftt == u'Šalis:' and not info.studio:
            val = p.find('span')
            info.studio = None if not val else val.getText()

        elif ftt == u'Žanras:' and not info.genre:
            val = p.find('span')
            info.genre = None if not val else val.getText()

        elif ftt == u'Režisierius:' and not info.director:
            val = p.find('span')
            info.director = None if not val else val.getText()

        elif ftt == u'Aktoriai:' and not info.cast:
            info.cast = []
            for a in p.find_all('a'):
                if a is not None:
                    info.cast.append(a.getText())

        elif ftt == u'Kalba:':
            val = p.find('span')
            if val:
                if val.getText().lower() == u"anglų + lt titrai":
                    data.lang = "en"
                    data.subtitle = "lt"
                elif "Lietuv" in val.getText():
                    data.lang = "lt"
                elif "Angl" in val.getText():
                    data.lang = "en"
                elif "Rus" in val.getText():
                    data.lang = "ru"

        elif ftt == u'Pridėta:' and not info.tagline:
            val = p.find('span')
            info.tagline = None if not val else val.getText()


def process_top100():
    soup = _make_beautifulsoup(_fix_url(top_url))
    array = []
    vid_content = soup.find(id='dle-content')
    if not vid_content:
        return None

    top_no = 1
    for listing in vid_content.find_all('li'):
        try:
            img = listing.find('img')
            title, _, season = _process_titles(img['alt'].encode('utf-8'))
            data = VideoMenu(
                "[COLOR green]#{}:[/COLOR] {}".format(top_no, title),
                img_url=_fix_url(img['src']),
                page_url=_fix_url(listing.find('a')['href']),
                season=season,
                # year=year,
                top250=top_no
            )
            array.append(data)
        except AttributeError:
            pass
        finally:
            top_no += 1

    if len(array) == 0:
        return None
    return array


def process_video_page(url, sort_by=None):
    """
    Responsible for getting video pages in list/grid pages
    :param sort_by: Sort by value: date, rating, new_read, comm_num, title
    :type url: str
    :rtype: list of VideoMenu
    """
    headers = None
    if sort_by:
        sort_by = {
            "dlenewssortby": sort_by,
            "dledirection": "asc" if sort_by == 'title' else "desc",
            "set_new_sort": "dle_sort_cat",
            "set_direction_sort": "dle_direction_cat",
        }
        headers = {
            # 'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            # 'Accept-Language': "en-US,en;q=0.5",
            'Content-Type': "application/x-www-form-urlencoded"
        }
    soup = _make_beautifulsoup(_fix_url(url), sort_by, headers)
    array = []
    vid_content = soup.find(id='dle-content')
    if not vid_content:
        return None, None

    # Getting videos
    for listing in vid_content.find_all('div', class_=['short-in', 'shortstory']):

        # Formatting title
        title = listing.find('img')['alt'].encode('utf-8')
        # titles = listing.find('div', class_='short-title')
        # title = titles.find('h3').getText().encode('utf-8')
        # otitle = titles.find('span').getText().encode('utf-8')
        title, otitle, season = _process_titles(title)

        em = listing.find('span', class_='short-label')
        if not em:
            try:
                p = listing.find('div', class_='short-fields').find('p')
                if p.find('em').getText() == u'Pridėta:':
                    em = p.find('span')
            except AttributeError:
                pass
        tagline = None if not em else em.getText().encode('utf8')

        quality = listing.find('span', class_='short-qual')
        codec = None if not quality else quality.getText().encode('utf8')

        data = VideoMenu(
            title,
            img_url=_fix_url(listing.find('img')['src']),
            page_url=_fix_url(listing.find('a')['href']),
            codec=codec,
            originaltitle=otitle,
            tagline=tagline,
            season=season,
        )

        # _process_fields(listing.find('div', class_='short-fields'), data)

        # st = listing.find('div', class_='short-text')
        # if st is not None:
        #     data.info.plot = st.getText().encode('utf8')
        if data.info.tagline:
            # log('Title: {}; Tagline: {}'.format(type(data.info.title), type(data.info.tagline)))
            data.info.title += ' [COLOR red]{}[/COLOR]'.format(data.info.tagline)

        array.append(data)

    # Getting pages
    paging = Paging()
    try:
        pages = vid_content.find('div', class_='pages')
        for s in pages.find_all('span'):
            if s.getText() == '...':
                continue
            paging.current = int(s.getText())
            a = pages.find_all('a')
            if len(a) > 1:
                paging.total = int(a[-1].getText())
            elif len(a) == 1:
                paging.total = 2
            else:
                break
            if paging.current >= paging.total:
                break
            paging.next_link = vid_content.find('span', class_='page-next').find('a')['href']
            break
    except AttributeError:
        paging = None
    if len(array) == 0:
        return None, None
    return array, paging


def progress_search(phrase, page):
    data, paging = process_video_page(_fix_url(search_url.format(phrase, page)))
    if paging:
        paging.current = page + 1
        paging.next_page = page + 2
        if paging.current >= paging.total:
            return data, None
    return data, paging


def progress_video(url):
    """
    :type url: str
    :rtype: Video
    """
    soup = _make_beautifulsoup(_fix_url(url))
    fstory = soup.find('div', id='fullstory')
    if not fstory:
        fstory = soup.find('div', id='dle-content')
    data = Video()
    info = VideoInfo.load_current()

    try:
        info.plot = fstory.find('div', class_='f-text').getText()
    except AttributeError:
        log("Failed get plot")

    # try:
    #     spans = fstory.find('div', class_='fstory-rating').find_all('span')
    #     info.votes = u"Už: {}, prieš: {}".format(spans[0].getText(), spans[1].getText())
    # except AttributeError:
    #     log("Failed get votes")

    # try:
    #     date = fstory.find('div', class_='bar-newsinfo').find('small').getText()
    #     if date.count('-') == 2:
    #         info.dateadded = "{2}-{1}-{0} 00:00:00".format(*date.replace(' ', '').split('-'))
    # except AttributeError:
    #     log("Failed get dateadded")

    try:
        data.img_url = _fix_url(fstory.find('div', class_=['full-poster', 'f-poster']).find('img')['src'])
    except AttributeError:
        log("Failed get thumbnail")

    # if not info.title:
    title = fstory.find('h1', id='s-title')
    if not title:
        t = fstory.find('h1', class_='f-title')
        title = t.find('span').getText().encode('utf-8')
        otitle = t.find('small').getText().encode('utf-8')
    else:
        title = title.getText().encode('utf-8')
        otitle = fstory.find('span', class_="full-original-title").getText().encode('utf-8')
    # except AttributeError:
    #     otitle = None
    title, _, season = _process_titles(title, otitle)
    info.title = title
    # info.year = year
    info.season = season

    # data, info = _process_f_table(fstory.find('ul', class_="f-table"), data, info)

    for iframe in fstory.find_all('iframe'):
        try:
            # For each source
            src = iframe['src']
            try:
                if "youtube.com" in src:
                    data.trailer_url = src
                    continue
            except KeyError:
                pass
            is_series, source = _grab_source(src, info)
            if is_series:
                data.is_series = is_series
                data.sources = source
                break
            else:
                data.sources.append(source)

        except NotImplementedError:
            continue

    return data


def _grab_source(url, info):
    if root_url_sort not in url:
        raise NotImplemented

    log("Grabbing source from %s" % url)

    is_series = False
    new_soup = _make_beautifulsoup(url)
    script = new_soup.find_all('script')[-1].getText()
    sindex = None
    for x in ["new Uppod({", "Playerjs({"]:
        if x in script:
            sindex = script.index(x)
            break
    if not sindex:
        raise UpdateException('Nepavyko rasti filmo šaltinių')
    json_data = script[sindex+len(x)-1:script.index("});")+1]
    log("JSON: " + json_data)
    json_data = json_data.replace("'", '"')
    json_data = re.sub(r'([a-zA-Z0-9_]+)(:(\"[^\";]+\"|{|\[|[0-9]+))', r'"\1"\2', json_data)
    # json_data = json_data.replace('id:', '"id":').replace('file:', '"file":')
    log("Modded JSON: " + json_data)
    data = json.loads(json_data)

    titles = new_soup.find_all('title')

    if len(titles) > 0 and titles[0].getText()[-4:] == ".txt":
        # If series, get all series sources
        is_series = True
        source = []
        for i, sscr in enumerate(data.get('pl', data.get('file', data))['playlist']):
            linfo = VideoInfo(**info.compose())
            comment = sscr.get('comment', 'Serija %d' % i)
            linfo.episode = int(re.findall('\d+', comment)[0])
            msg = "{} {}" if not isinstance(linfo.title, unicode) else u"{} {}"  # unicode nightmare
            linfo.title = msg.format(linfo.title, sscr['comment'].strip())
            source.append(Source(_fix_url(sscr['file'] + "|" + urllib.urlencode({"User-Agent": user_agent})), linfo))

    else:
        # Must be a movie
        source = Source(_fix_url(data['file'] + "|" + urllib.urlencode({"User-Agent": user_agent})), info)
    return is_series, source
