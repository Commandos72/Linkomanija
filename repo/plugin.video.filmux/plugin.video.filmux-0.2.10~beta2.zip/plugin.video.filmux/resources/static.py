# -*- coding: utf-8 -*-
"""
This file contains static variables
for menu mapping and urllib2.
"""
import xbmc
import xbmcaddon

debug = xbmcaddon.Addon().getSetting('debug')

__all__ = ['log', 'VideoInfo', 'Video', 'VideoMenu', 'Menu', 'Source', 'user_agent', 'root_url', 'root_url_sort',
           'search_url', 'Paging', 'top_url', 'UpdateException']
user_agent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'

root_url = "https://filmux.org"
root_url_sort = "filmux.org"
search_url = "/index.php?do=search&subaction=search&search_start={1}&full_search=0&result_from=13&story={0}"
top_url = "/top-100.html"


def log(s):
    if debug:
        if isinstance(s, unicode):
            s = s.encode('ascii', 'replace').decode("'utf-8")
        xbmc.log("FILMUX.ORG: {}".format(s), xbmc.LOGNOTICE)


class UpdateException(Exception):
    pass


class Menu:
    Link, Menu, Search, Top, Year, Director, Country, Actor = range(8)

    def __init__(self, option, label, additional=None):
        """
        :param option: Action once menu is selected
        :param label: Label of menu
        """
        self.option = option
        self.label = label
        self.additional = additional

        if isinstance(option, str):
            self.type = Menu.Link
        elif isinstance(option, list):
            self.type = Menu.Menu
        else:
            self.type = option


class Paging:
    def __init__(self, page=None, next=None, total=None, link=None):
        self.next_link = link
        self.next_page = next
        self.total = total
        self.current = page


class VideoInfo:
    def __init__(self, title=None, year=None, genre=None, director=None, cast=None, episode=None,
                 season=None, plot=None, originaltitle=None, votes=None, trailer=None, dateadded=None, studio=None,
                 tagline=None, plotoutline=None, top250=None):
        # Header
        self.title = title  # Actual title
        self.originaltitle = originaltitle  # Title in english
        self.dateadded = dateadded
        self.year = year

        # Within content
        self.genre = genre
        self.studio = studio  # Country
        self.director = director
        self.cast = cast
        self.plot = plot
        self.plotoutline = plotoutline  # Shorter description provided in videos menu page.
        self.votes = votes

        # Additional
        self.trailer = trailer

        # Series only
        self.episode = episode
        self.season = season
        self.tagline = tagline  # Info, usually last update

        # TOP100
        self.top250 = top250

    def compose(self):
        data = {}
        for key, val in self.__dict__.items():
            if val is not None:
                data[key] = val
        log("Video found: %s" % data['title'])
        return data

    @staticmethod
    def load_current():
        info = VideoInfo()
        for key in info.__dict__.keys():
            val = unicode(xbmc.getInfoLabel("ListItem.{}".format(key)), 'utf-8')
            if val == '':
                continue
            setattr(info, key, val)
        if info.season:
            info.season = int(info.season)
        if info.episode:
            info.episode = int(info.episode)
        if info.cast:
            info.cast = info.cast.split('\n')
        return info


class VideoMenu:
    def __init__(self, title, img_url=None, codec=None, page_url=None, **info):
        self.page_url = page_url
        self.img_url = img_url
        self.codec = codec
        self.lang = None
        self.subtitle = None
        self.info = VideoInfo(title, **info)


class Video:
    def __init__(self):
        self.sources = []
        self.trailer_url = None  # raw youtube link
        self.img_url = None
        self.codec = None  # Rather just quality than codec
        self.lang = None
        self.subtitle = None
        self.is_series = False

    def add_source(self, sources):
        """
        :type sources: Source
        """
        self.sources.append(sources)

    def get_sources(self):
        """
        :rtype: list of Source
        """
        return self.sources


class Source:
    def __init__(self, url, info):
        """
        :param url: Url link to source steam
        :type info: VideoInfo
        """
        self.url = url
        self.info = info


genres_films = [
    Menu("/filmai/", "Visi filmai")
] + sorted([
    Menu("/filmai/dramos/", "Dramos"),
    Menu("/filmai/siaubo/", "Siaubo"),
    Menu("/filmai/trileriai/", "Trileriai"),
    Menu("/filmai/mistiniai/", "Mistiniai"),
    Menu("/filmai/veiksmo/", "Veiksmo"),
    Menu("/filmai/kariniai/", "Kariniai"),
    Menu("/filmai/vesternai/", "Vesternai"),
    Menu("/filmai/komedijos/", "Komedijos"),
    Menu("/filmai/romantiniai/", "Romantiniai"),
    Menu("/filmai/istoriniai/", "Istoriniai"),
    Menu("/filmai/muzikiniai/", "Muzikiniai"),
    Menu("/filmai/nuotykiu/", "Nuotykių"),
    Menu("/filmai/seimai/", "Šeimai"),
    Menu("/filmai/fantastiniai/", "Fantastiniai"),
    Menu("/filmai/kriminaliniai/", "Kriminaliniai"),
    Menu("/filmai/dokumentiniai/", "Dokumentiniai"),
    Menu("/filmai/biografinis/", "Biografiniai"),
    Menu("/filmai/detektyviniai/", "Detektyviniai"),
    Menu("/filmai/sportas/", "Sportas"),
], key=lambda x: x.label) + [
    Menu("/filmai/filmai-lt/", "Filmai Lietuviškai"),
    Menu("/filmai/filmai-en/", "Filmai Angliškai"),
    Menu("/filmai/filmai-ru/", "Filmai Rusiškai"),
    Menu("/filmai/filmai-lt-sub/", "Filmai su subtitrais")
]

genres_series = [
    Menu("/serialai/", "Visi serialai")
] + sorted([
    Menu("/serialai/drama/", "Dramos"),
    Menu("/serialai/siaubas/", "Siaubo"),
    Menu("/serialai/trileris/", "Trileriai"),
    Menu("/serialai/mistika/", "Mistiniai"),
    Menu("/serialai/veiksmas/", "Veiksmo"),
    Menu("/serialai/karinis/", "Kariniai"),
    Menu("/serialai/vesternas/", "Vesternai"),
    Menu("/serialai/komedija/", "Komedijos"),
    Menu("/serialai/romantika/", "Romantiniai"),
    Menu("/serialai/istorinis/", "Istoriniai"),
    Menu("/serialai/muzikinis/", "Muzikiniai"),
    Menu("/serialai/nuotykiai/", "Nuotykių"),
    Menu("/serialai/seimos/", "Šeimai"),
    Menu("/serialai/fantastika/", "Fantastiniai"),
    Menu("/serialai/dokumentika/", "Dokumentiniai"),
    Menu("/serialai/kriminalai/", "Kriminaliniai"),
    Menu("/serialai/detektyvai/", "Detektyviniai"),
    Menu("/serialai/sport/", "Sportas"),
    Menu("/serialai/biografiniai/", "Biografiniai"),
], key=lambda x: x.label) + [
    Menu("/serialai/serialai-lt/", "Serialai Lietuviškai"),
    Menu("/serialai/serialai-en/", "Serialai Angliškai"),
    Menu("/serialai/serialai-ru/", "Serialai Rusiškai"),
    Menu("/serialai/serialai-lt-sub/", "Serialai su subtitrais")
]

menu_films = [
    Menu(genres_films, "Pagal datą"),
    Menu(genres_films, "Pagal įvertinimą", additional={'sort': 'rating'}),
    Menu(genres_films, "Pagal žiūrimumą", additional={'sort': 'news_read'}),
    Menu(genres_films, "Pagal komentarus", additional={'sort': 'comm_num'}),
    Menu(genres_films, "Pagal abecėlę", additional={'sort': 'title'}),
]

menu_series = [
    Menu(genres_series, "Pagal datą"),
    Menu(genres_series, "Pagal įvertinimą", additional={'sort': 'rating'}),
    Menu(genres_series, "Pagal žiūrimumą", additional={'sort': 'news_read'}),
    Menu(genres_series, "Pagal komentarus", additional={'sort': 'comm_num'}),
    Menu(genres_series, "Pagal abecėlę", additional={'sort': 'title'}),
]

menu_anime = [
    Menu("/animacija/", "Pagal datą"),
    Menu("/animacija/", "Pagal įvertinimą", additional={'sort': 'rating'}),
    Menu("/animacija/", "Pagal žiūrimumą", additional={'sort': 'news_read'}),
    Menu("/animacija/", "Pagal komentarus", additional={'sort': 'comm_num'}),
    Menu("/animacija/", "Pagal abecėlę", additional={'sort': 'title'}),
]

main_menu = [
    Menu("/index.php?do=lastnews", "Naujienos"),
    Menu(menu_films, "Filmai"),
    Menu(menu_series, "Serialai"),
    Menu(menu_anime, "Animacija"),
    Menu("/tv-laidos", "TV Laidos"),
    Menu(Menu.Top, "TOP 100"),
    Menu(Menu.Search, "Paieška..."),
]
