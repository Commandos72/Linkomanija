﻿#!/usr/local/bin/python
# -*- coding: utf-8 -*-

import ssl
import sys
import urllib2
from urlparse import parse_qsl

from resources import static, libfilmux as filmux
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

_url = sys.argv[0]
_handle = int(sys.argv[1])
_addon = xbmcaddon.Addon()
_name = _addon.getAddonInfo('name')
_icon = _addon.getAddonInfo('icon')


def play_video(link):
    """
    Play a video.
    """
    play_item = xbmcgui.ListItem(path=link)
    play_item.setInfo(type="video", infoLabels=static.VideoInfo.load_current().compose())
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def list_link(link=None, add=None):
    """
    Opens a regular menu.
    """
    menus = static.main_menu
    if link is not None:
        for menu_no in link.split('.'):
            menus = menus[int(menu_no)].option
    listing = []
    for entry, menu in enumerate(menus):
        list_item = xbmcgui.ListItem(label=menu.label)
        additional = add or {}
        if menu.additional:
            additional.update(menu.additional)

        if menu.type is static.Menu.Menu:
            link0 = entry if link is None else "{}.{}".format(link, entry)
            url = '{0}?action=list&link={1}'.format(_url, link0)
        elif menu.type is static.Menu.Link:
            url = '{0}?action=open&link={1}'.format(_url, menu.option)
        elif menu.type is static.Menu.Search:
            url = '{0}?action=find'.format(_url)
        elif menu.type is static.Menu.Top:
            url = '{0}?action=top100'.format(_url)
        else:
            continue

        for k, v in additional.items():
            url += '&{}={}'.format(k, v)
        listing.append((url, list_item, True))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)


def open_link(data, paging=None, next_url=None, add=None):
    """
    Opens videos menu & renders list of available videos.
    :type data: list of static.VideoMenu
    :type paging: static.Paging
    :param next_url: Next page plugin URL
    """
    if not data:
        xbmcgui.Dialog().notification(_name, "Nieko nerado", icon=xbmcgui.NOTIFICATION_INFO)
        return

    listing = []
    for video in data:
        list_item = xbmcgui.ListItem(video.info.title, thumbnailImage=video.img_url)
        list_item.setInfo(type="video", infoLabels=video.info.compose())
        if video.lang:
            list_item.addStreamInfo("audio", {'language': video.lang})
        if video.codec:
            list_item.addStreamInfo('video', {'codec': video.codec})
        url = '{0}?action=view&link={1}'.format(_url, video.page_url)
        listing.append((url, list_item, True))
    if paging:
        if next_url is None:
            next_url = '{0}?action=open&link={1}'.format(_url, paging.next_link)
        if add:
            for k, v in add.items():
                next_url += '&{}={}'.format(k, v)
        list_item = xbmcgui.ListItem(label="[COLOR blue]Sekantis (Puslapis {} iš {})[/COLOR]"
                                     .format(paging.current, paging.total))
        listing.append((next_url, list_item, True))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)


def open_video(link):
    """
    Open video page, grabs available video info and streams.
    :param link: Video page link
    """
    data = filmux.progress_video(link)
    art = data.img_url
    if data.trailer_url:
        try:
            s = data.trailer_url
            video_id = s[s.index('/embed/') + 7:s.index('?')]
            art = "https://img.youtube.com/vi/{}/0.jpg".format(video_id)
            list_item = xbmcgui.ListItem(label="Pristatymas", thumbnailImage=art)
            list_item.setProperty('fanart_image', art)
            if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)') == 1:
                url = 'plugin://plugin.video.youtube/?action=play_video&videoid={}'.format(video_id)
                list_item.setProperty('IsPlayable', 'true')
            else:
                url = '{0}?action=dialog&text={1}'.format(_url, "Nerasta įrengto youtube!")
            xbmcplugin.addDirectoryItem(_handle, url, listitem=list_item)
        except ValueError:
            pass
    for src in data.get_sources():
        # url = '{0}?action=play&video={1}'.format(_url, src.url)
        list_item = xbmcgui.ListItem(src.info.title, thumbnailImage=data.img_url)
        list_item.setProperty('fanart_image', art)
        list_item.setInfo(type="video", infoLabels=src.info.compose())
        if data.lang:
            list_item.addStreamInfo("audio", {'language': data.lang})
        if data.subtitle:
            list_item.addStreamInfo("subtitle", {'language': data.subtitle})
        list_item.setProperty('IsPlayable', 'true')
        # listing.append((src.url, list_item, False))
        xbmcplugin.addDirectoryItem(_handle, src.url, listitem=list_item)
    xbmcplugin.endOfDirectory(_handle)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    if params:
        additional = params.copy()
        for opt in ['action', 'link', 'video', 'page', 'name', 'text']:
            if opt in additional:
                del additional[opt]

        if params['action'] == 'list':
            # Display the list of menus in a provided in static.py.
            list_link(params['link'], additional)

        elif params['action'] == 'open':
            # Generate list from website.
            videos = filmux.process_video_page(params['link'], params['sort'] if 'sort' in params else None)
            open_link(*videos, add=additional)

        elif params['action'] == 'view':
            # Open video menu (form source).
            open_video(params['link'])

        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])

        elif params['action'] == 'find':
            # Do a search command
            if 'page' in params:
                page = int(params['page'])
                text = params['name']
            else:
                page = 0
                text = urllib2.quote(xbmcgui.Dialog().input('Įveskite paieškos frazę'))
            data, paging = filmux.progress_search(text, page)
            url = '{0}?action=find&name={1}&page={2}'.format(_url, text, page + 1)
            open_link(data, paging, url)

        elif params['action'] == 'top100':
            open_link(filmux.process_top100())

        elif params['action'] == 'dialog':
            xbmcgui.Dialog().notification(_name, params['text'], icon=xbmcgui.NOTIFICATION_WARNING)

    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_link()

if __name__ == '__main__':
    try:
        router(sys.argv[2][1:])
    except urllib2.HTTPError as e:
        xbmcgui.Dialog().notification(_name, "Jungimosi klaida {}".format(e.code), icon=xbmcgui.NOTIFICATION_ERROR)

    except urllib2.URLError as e:
        xbmcgui.Dialog().notification(_name, "Nepavyko prisijungti.", str(e.reason), icon=xbmcgui.NOTIFICATION_ERROR)

    except ssl.SSLError as e:
        if e.message == 'The read operation timed out':
            xbmcgui.Dialog().notification(_name, "Filmux.org puslapis negražino atsakymo", "Bandykite vėliau",
                                          icon=xbmcgui.NOTIFICATION_ERROR)
        else:
            xbmcgui.Dialog().notification(_name, "Jungimosi klaida!", e.message, icon=xbmcgui.NOTIFICATION_ERROR)

    except static.UpdateException as e:
        xbmcgui.Dialog().notification(_name, "Puslapio klaida", e.message, icon=xbmcgui.NOTIFICATION_ERROR)
