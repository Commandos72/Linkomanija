import requests, cookielib, filesystem, urllib2, json, re
from bs4 import BeautifulSoup

catalog = [
	('Movies', 29, 30100),
	('Movies LT', 53, 30101),
	('Movies RU', 51, 30102),
	('Movies HD', 52, 30103),
	('Movies LT HD', 61, 30104),
	('Movies RU HD', 64, 30105),
	('TV', 30, 30106),
	('TV LT', 28, 30107),
	('TV RU', 65, 30108),
	('TV HD', 60, 30109),
	('TV LT HD', 62, 30110),
	('Documentaries', 58, 30111),
	('Sport', 46, 30112),
	('Anime', 38, 30113),
]
try:
	import xbmc
	lang_id = xbmc.getLanguage(xbmc.ISO_639_1)
except:
	lang_id = 'ru'

class TMDB_API(object):
	@staticmethod
	def url_imdb_id(idmb_id, lang):
		
		host = 'api.tmdb.org'
		key = 'ecbc86c92da237cb9faff6d3ddc4be6d'

		url = 'http://%s/3/find/%s?api_key=%s&language=%s&external_source=imdb_id' % (host, idmb_id, key, lang)
		tmdb_data 	= json.load(urllib2.urlopen( url ))

		for type in ['movie', 'tv']:
			try:
				id = tmdb_data['%s_results' % type][0]['id']
				return 'http://%s/3/' % host + type + '/' + str(id) + '?api_key=' + key + '&language=%s&append_to_response=credits' % lang
			except: pass

		return None

	def __init__(self, imdb_id = None, lang=None):
		if lang=='KODI' or lang is None:
			self.lang_id = lang_id
		elif lang:
			self.lang_id = lang.lower()

		if imdb_id:
			url_ = TMDB_API.url_imdb_id(imdb_id, self.lang_id)
			try:
				if url_:
					self.tmdb_data 	= json.load(urllib2.urlopen( url_ ))
			except:
				pass

class DictDiffer(object):
	"""
	Calculate the difference between two dictionaries as:
	(1) items added
	(2) items removed
	(3) keys same in both but changed values
	(4) keys same in both and unchanged values
	"""
	def __init__(self, current_dict, past_dict):
		self.current_dict, self.past_dict = current_dict, past_dict
		self.set_current, self.set_past = set(current_dict.keys()), set(past_dict.keys())
		self.intersect = self.set_current.intersection(self.set_past)
	def added(self):
		return self.set_current - self.intersect 
	def removed(self):
		return self.set_past - self.intersect 
	def changed(self):
		return set(o for o in self.intersect if self.past_dict[o] != self.current_dict[o])
	def unchanged(self):
		return set(o for o in self.intersect if self.past_dict[o] == self.current_dict[o])

class TMDB_QUERY(object):
	def __init__(self, imdb_id, languages):
		self.languages = [ TMDB_API(imdb_id, lang) for lang in languages.split('>') ]
		self.imdb_id = imdb_id
		self.clean_lt()

	def clean_lt(self):
		lt_dict = None
		lt_api = None
		en_dict = None

		if len(self.languages) < 2:
			return

		for lang in self.languages:
			if lang.lang_id == 'lt':
				lt_dict = lang.tmdb_data
				lt_api = lang
			if lang.lang_id == 'en':
				en_dict = lang.tmdb_data

		if not lt_api:
			return

		if not en_dict:
			en_dict = TMDB_API(self.imdb_id, 'en').tmdb_data

		d = DictDiffer(lt_dict, en_dict)
		lt_api.tmdb_data = { k : lt_dict[k] for k in d.changed() if lt_dict[k] }

	def __getitem__(self, key):

		if key == 'credits':
			return self.credits()

		for lang in self.languages:
			if key in lang.tmdb_data:
				return lang.tmdb_data[key]

		raise KeyError

	def get(self, key, default=None):
		try:
			return self.__getitem__(key)
		except KeyError:
			return default

	def credits(self):
		result = {}
		for lang in reversed( self.languages ):
			if 'credits' in lang.tmdb_data:
				result = dict(lang.tmdb_data['credits'], **result)

		return result

class soup_base(object):
	def __init__(self, url, owner):
		self._soup = None
		self._url = url
		self._owner = owner

	@property
	def soup(self):
		if not self._soup:
			r = self._owner._request(self._url)
			self._soup = BeautifulSoup(r.content, 'html.parser')
		return self._soup

def split_list(s):
	return s.split(', ')

def imdb_rating(s):
	r = requests.get(s)
	import re
	m = re.search('<span itemprop="ratingValue">([\d,\.])</span>', r.content)
	if m:
		return m.group(1).replace(',', '.')

def _get_cast(castData):
	listCast = []
	listCastAndRole = []
	listCastAndRoleFull = []
	for castmember in castData:
		listCast.append(castmember["name"])
		listCastAndRole.append(u"{}|{}".format(castmember["name"], castmember["character"]))

		if castmember["profile_path"]:
			thumbnail = 'http://image.tmdb.org/t/p/original' + castmember["profile_path"]
		else:
			thumbnail = None

		listCastAndRoleFull.append({
				'name'          : castmember["name"],
				'role'          : castmember["character"],
				'thumbnail'     : thumbnail,
				'order'         : castmember['order']
		})
	return [listCast, listCastAndRole, listCastAndRoleFull]


class page_topic(soup_base):

	"""
	def get_data(self, text):

		return {
			'Director':		('director', unicode),
			'Writer':		('writer', unicode),
			'Actors':		('cast', split_list),
			'IMDb':			('imdbnumber', imdb_rating),
			'Genre':		('genre', unicode),
			'Plot Summary': ('plot', unicode)
		}.get(text)
	"""

	def content(self):
		infoVideo = {}
		info = {}

		td = self.soup.find('td', class_='descr_text')
		if td:
			"""
			bbs = td.find_all('b')
			info['label'] = bbs[0].get_text()

			for b in bbs[1:]:
				data = self.get_data(b.get_text())
				if data:
					infoVideo[data[0]] = data[1](b.next_sibling.get_text())
			"""

			for a in td.find_all('a'):
				if 'imdb' in a['href']:
					m = re.search('(tt\d+)', a['href'])
					if m:
						imdb = m.group(1)
						tmdb = TMDB_QUERY(imdb, self._owner.settings.lang)

						try:
							infoVideo['title'] = tmdb['title']
							infoVideo['originaltitle'] = tmdb['original_title']
						except KeyError:
							infoVideo['title'] = tmdb.get('name')
							infoVideo['originaltitle'] = tmdb.get('original_name')

						infoVideo['plot'] = tmdb['overview']
						infoVideo['genre'] = u', '.join([i['name'] for i in tmdb['genres']])
						try:
							infoVideo['year'] = int(tmdb['release_date'].split('-')[0])
						except KeyError:
							infoVideo['year'] = int(tmdb['first_air_date'].split('-')[0])
						infoVideo['rating'] = tmdb['vote_average']
						try:
							infoVideo['duration'] = int(tmdb['runtime']) * 60
						except: pass
						infoVideo['votes'] = tmdb['vote_count']

						cast = _get_cast(tmdb['credits']['cast'])
						infoVideo['cast'] = cast[0]
						infoVideo['castandrole'] = cast[1] 
						info['cast'] = cast[2] 

						poster = 'http://image.tmdb.org/t/p/original' + tmdb['poster_path']
						fanart = 'http://image.tmdb.org/t/p/original' + tmdb['backdrop_path']

						info['icon'] = poster
						info['thumb'] = poster
						info['fanart'] = fanart
						info['label'] = infoVideo['title']

						pass

		info['info'] = { 'video': infoVideo }
		return info

class page_category(soup_base):
	def item(self, a):
		tr = a.find_parent('tr')
		td = a.find_parent('td')

		tds = tr.find_all('td')

		desc = td.find('span').get_text()

		details = td.find('a')

		info = { 'label': details.get_text(), 'url_details': details['href'], 
				'url_download': a['href'],
				'seeders': tds[7].get_text(), 'leechers': tds[8].get_text(),
				'desc': desc }

		return info

	def content(self):
		return [ self.item( a ) for a in self.soup.find_all('a', class_='index') if '.torrent' in a['href'] ]

class AuthorizeError(Exception):
	def __str__(self):
		return 'Login or password is wrong'

class linkomanija(object):
	
	_proto = 'https'
	_host = 'www.linkomanija.net'
	
	def __init__(self, settings):
		self.settings = settings

		cookie_path = filesystem.join(settings.config_dir, 'cookies.txt')
		self.session = requests.session()
		self.session.cookies = cookielib.LWPCookieJar(filename=cookie_path)

	def make_url(self, path, query={}):
		import urlparse, urllib
		pr = urlparse.ParseResult(self._proto, self._host, path, None, urllib.urlencode(query), None)
		return urlparse.urlunparse(pr)		
		
	def category_list(self, category, page=0):
		url = self.make_url('browse.php', {'cat': category, 'page': page})

		page = page_category(url, self)
		return page.content()

	def search(self, s, cat=None):
		params = {'search': s}
		if cat:
			params['c'+str(cat)] = '1'
		url = self.make_url('browse.php', params)
		page = page_category(url, self)
		return page.content()

	def topic(self, url):
		url = self.make_url(url)

		page = page_topic(url, self)
		return page.content()

	def download_torrent(self, url, path):
		req = self._request(self.make_url(url))
		if req.ok:
			with filesystem.fopen(path, 'wb') as out:
				for chunk in req.iter_content(1024):
					out.write(chunk)

	def torrent_name(self, url):
		import urlparse, urllib
		res = urlparse.urlparse(url)
		params = urlparse.parse_qs(res.query)

		return params['name'][0]
				
		
	def _need_autorize(self, req):
		return 'takelogin.php' in req.content

	def _authorize(self):
		import urlparse
		url = self.make_url('takelogin.php')

		data = {
			'username': self.settings.login,
			'password': self.settings.password,
			'commit':'Prisijungti',
			'login_cookie':'1'
		}

		r = self.session.post(url, data=data, verify=False)
		self.session.cookies.save()

		return r
		
	def _request(self, url, stream=None):
		req = self.session.get(url, stream=stream, verify=False)
		
		if self._need_autorize(req):
			auth = self._authorize()
			if self._need_autorize(auth):
				raise AuthorizeError()

			if auth.ok:
				req = self.session.get(url, stream=stream, verify=False)
				
		return req