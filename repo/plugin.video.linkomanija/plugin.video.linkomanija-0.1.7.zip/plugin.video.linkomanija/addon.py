# coding: utf-8

from simpleplugin import Plugin
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
from lib.linkomanija import linkomanija, AuthorizeError

plugin = Plugin()
_addon_title_ = plugin.addon.getAddonInfo('name')
_ = plugin.initialize_gettext()

_linkomanija = linkomanija(plugin)

def plugin_fanart():
	return xbmc.translatePath('special://home/addons/plugin.video.linkomanija/fanart.jpg')

def show_not_authorized():
	xbmcgui.Dialog().ok(_('Not autorized'), _('Enter your login/password correctly'))
	plugin.addon.openSettings()

def root_item_category(item):
	label = plugin.get_localized_string(item[2])
	if not label:
		label = item[0]

	return { 'label': label, 'url': plugin.get_url(action='category_list', cat=item[1]), 'fanart': plugin_fanart() }
	
def root_item_search():
	result = {'label': '['+_('Search')+']', 'url': plugin.get_url(action='search'), 'fanart': plugin_fanart() }
	return result

@plugin.action()
def root(params):
	xbmcplugin.setContent(int(sys.argv[1]), 'files')

	from lib.linkomanija import catalog
	
	items = [root_item_category(item) for item in catalog]
	items.insert(0,root_item_search())
	
	return items

@plugin.action()
def topic(params):
	import vsdbg
	vsdbg._bp()

	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	topic_data = _linkomanija.topic(params['url_details'])

	import filesystem

	url_download = params['url_download']
	name = _linkomanija.torrent_name(url_download)
	path = filesystem.join(plugin.config_dir, name)

	_linkomanija.download_torrent(url_download, path)

	def get_list(path):
		from torrentplayer import TorrentPlayer
		tp = TorrentPlayer()
		tp.AddTorrent(path)
		return tp.GetLastTorrentData()['files']

	files = []
	ll = get_list(path)
	
	if ll and ll[0]['name'].startswith('BDMV'):
		# find max file index
		indx = 0
		size = 0
		for f in ll:
			if f['size'] > size:
				indx = f['index']
				size = f['size']
		td = topic_data.copy()
		td['url'] = plugin.get_url(action='play', index=indx, torrent=path)
		td['is_playable'] = True
		return [td]

	for f in ll:
		td = topic_data.copy()
		td['url'] = plugin.get_url(action='play', index=f['index'], torrent=path)
		td['label'] = f['name']
		td['is_playable'] = True
		files.append(td)

	return files

@plugin.action()
def play(params):
	import sys, xbmcgui
	
	#import vsdbg
	#vsdbg._bp()

	info_dialog = xbmcgui.DialogProgress()
	info_dialog.create(_addon_title_)

	from player import play_torrent
	play_torrent(params['torrent'], plugin, info_dialog, _addon_title_)

	info_dialog.update(0, '', '')
	info_dialog.close()


def category_topic_item(info):

	label = u'[{}/{}] {}'.format(info['seeders'], info['leechers'], info['label'])

	return { 'label': label, 'url': plugin.get_url(action='topic', **info), 'fanart': plugin_fanart() }

def category_item_search(category):
	result = {'label': '['+_('Search in category')+']', 'url': plugin.get_url(action='search', category=category), 'fanart': plugin_fanart() }
	return result

def category_item_next(category, page):
	result = {'label': '['+_('Next page')+']', 'url': plugin.get_url(action='category_list', cat=category, page=page), 'fanart': plugin_fanart() }
	return result


@plugin.action()
def category_list(params):
	try:
		page = int(params.get('page', 0))

		xbmcplugin.setContent(int(sys.argv[1]), 'files')
		result = [ category_topic_item(i) for i in  _linkomanija.category_list(params['cat'], page) ]
		result.append(category_item_next(params['cat'], page+1))
		result.insert(0, category_item_search(params['cat']))
		return result

	except AuthorizeError:
		show_not_authorized()

@plugin.action()
def search(params):
	import sys, urllib
	if not 'keyword' in params:
		dlg = xbmcgui.Dialog()
		s = dlg.input(_('Enter search string'))
		if s:
			command = sys.argv[0] + sys.argv[2] + '&keyword=' + urllib.quote(s)
			xbmc.executebuiltin(b'Container.Update(\"%s\")' % command)
		return False

	s = urllib.unquote(params.get('keyword'))
	if s:
		#import vsdbg
		#vsdbg._bp()
		#page = int(params.get('page', 0))
		result = [ category_topic_item(i) for i in  _linkomanija.search(s, params.get('category')) ]
		return result
	return False
	
	
if __name__ == '__main__':
	#import vsdbg
	#vsdbg._bp()
	plugin.run()	